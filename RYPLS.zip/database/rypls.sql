-- phpMyAdmin SQL Dump
-- version 4.1.6
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 06, 2016 at 08:43 AM
-- Server version: 5.6.16
-- PHP Version: 5.5.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `rypls`
--

-- --------------------------------------------------------

--
-- Table structure for table `assign_remove_staff`
--

CREATE TABLE IF NOT EXISTS `assign_remove_staff` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `staff_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `venue_name` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `event_name` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `staff_role` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `available` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=63 ;

--
-- Dumping data for table `assign_remove_staff`
--

INSERT INTO `assign_remove_staff` (`id`, `staff_name`, `venue_name`, `event_name`, `staff_role`, `available`, `created_at`, `updated_at`) VALUES
(55, 'markpual890@gmail.com', 'party city', '15', 'Waitor', NULL, '2015-12-22 06:24:22', '2015-12-22 06:24:22'),
(56, 'jaffmaya@gmail.com', 'social events area', '16', 'Waitor', 'no', '2015-12-22 07:00:03', '2015-12-22 07:00:03'),
(57, 'bushra.khan@curiologix.com', 'resort side', '18', 'DJ', NULL, '2015-12-22 07:33:46', '2015-12-22 07:33:46'),
(58, 'jack@marquette.com', 'Marquette ', '29', 'Waitor', NULL, '2015-12-23 09:32:24', '2015-12-23 09:32:24'),
(59, 'markpual890@gmail.com', 'party city', '14', 'Dancer', NULL, '2015-12-28 06:39:59', '2015-12-28 06:39:59'),
(61, 'stevengill930@gmail.com', 'Wedding palace', '35', 'Waitor', NULL, '2016-01-01 07:11:37', '2016-01-01 07:11:37'),
(62, 'stevengill903@gmail.com', 'Wedding palace', '35', 'Dancer', 'no', '2016-01-01 07:37:31', '2016-01-01 07:37:31');

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE IF NOT EXISTS `comment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `venue_id` varchar(11) NOT NULL,
  `event_id` varchar(11) NOT NULL,
  `comments` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`id`, `user_id`, `venue_id`, `event_id`, `comments`, `created_at`, `updated_at`) VALUES
(1, 77, '0', '30', 'It''s a very noble cause.', '2015-12-31 06:15:27', '2015-12-31 06:15:27'),
(2, 77, '0', '30', 'Every one should participate in it.', '2015-12-31 07:20:07', '2015-12-31 07:20:07'),
(3, 77, '18', '0', 'We should appreciate this kind of things. ', '2015-12-31 08:11:57', '2015-12-31 08:11:57'),
(4, 75, '22', '0', 'try your', '2016-01-01 06:12:58', '2016-01-01 06:12:58'),
(5, 75, '0', '35', 'amazing', '2016-01-01 06:19:08', '2016-01-01 06:19:08'),
(6, 96, '22', '0', 'awsum', '2016-01-01 07:17:57', '2016-01-01 07:17:57'),
(7, 97, '22', '0', 'its going great', '2016-01-01 07:44:17', '2016-01-01 07:44:17');

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE IF NOT EXISTS `event` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `venue_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `event_name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(1000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `event_type` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `dree_code` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `music_type` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `price` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_from` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date_to` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `time_from` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `time_to` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `age_restriction` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `parking` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `facebook_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `twitter_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `youtube_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `latitude` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `longitude` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `recurring` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `photo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=36 ;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`id`, `user_id`, `venue_id`, `event_name`, `title`, `description`, `event_type`, `dree_code`, `music_type`, `price`, `date_from`, `date_to`, `time_from`, `time_to`, `age_restriction`, `parking`, `phone`, `facebook_url`, `twitter_url`, `youtube_url`, `latitude`, `longitude`, `recurring`, `photo`, `created_at`, `updated_at`) VALUES
(33, 76, '20', 'Wedding', 'Wedding', 'Starting of new journey', 'Wedding', '', 'Jazz', '44', '31 Dec 2015', '31 Dec 2015', '09 : 13  PM', '09 : 13  PM', '+16', 'No', '54352', 'www.facebook.com', 'www.twitter.com', 'www.google.com', NULL, NULL, 'No', 'event_2015-12-311584457049.png,event_2015-12-312096866567.png,event_2015-12-31596067270.png', '2015-12-31 11:18:15', '2015-12-31 11:18:15'),
(35, 75, '22', 'Grand wedding', 'Grand wedding', 'You are hire to arranged a grant wedding', 'Wedding', '', 'Disco', '360', '01 Jan 2016', '02 Jan 2016', '04 : 16  PM', '08 : 16  PM', '+18', 'Yes', '123456789123', 'www.facebook.com', 'www.twitter.com', 'www.gmail.com', NULL, NULL, 'Yes', 'event_2016-01-011064882567.png,event_2016-01-01443883994.png', '2016-01-01 06:18:39', '2016-01-01 06:18:39');

-- --------------------------------------------------------

--
-- Table structure for table `event_ratings`
--

CREATE TABLE IF NOT EXISTS `event_ratings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `venue_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `likes` int(11) NOT NULL,
  `event_likes` int(11) NOT NULL,
  `favourites` int(11) NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `event_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=42 ;

--
-- Dumping data for table `event_ratings`
--

INSERT INTO `event_ratings` (`id`, `user_id`, `venue_id`, `likes`, `event_likes`, `favourites`, `type`, `event_id`, `created_at`, `updated_at`) VALUES
(41, 97, '0', 0, 1, 1, 'event', '35', '2016-01-01 07:40:54', '2016-01-01 07:40:54');

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE IF NOT EXISTS `images` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `venue_id` varchar(11) NOT NULL,
  `event_id` varchar(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `images` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=42 ;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`id`, `user_id`, `venue_id`, `event_id`, `type`, `images`, `created_at`, `updated_at`) VALUES
(30, 76, '0', '35', 'event', 'event_2016-01-0420565.jpg', '2016-01-03 22:51:04', '2016-01-03 22:51:04'),
(31, 76, '0', '35', 'event', 'event_2016-01-0419050.jpg', '2016-01-03 22:51:04', '2016-01-03 22:51:04'),
(32, 76, '0', '35', 'event', 'event_2016-01-0411099.jpg', '2016-01-03 22:51:04', '2016-01-03 22:51:04'),
(33, 76, '0', '35', 'event', 'event_2016-01-0424568.jpg', '2016-01-03 22:51:04', '2016-01-03 22:51:04'),
(34, 76, '0', '35', 'event', 'event_2016-01-047377.jpg', '2016-01-03 22:51:04', '2016-01-03 22:51:04'),
(35, 76, '0', '35', 'event', 'event_2016-01-049014.jpg', '2016-01-03 22:58:31', '2016-01-03 22:58:31'),
(36, 76, '0', '35', 'event', 'event_2016-01-048759.jpg', '2016-01-03 22:58:31', '2016-01-03 22:58:31'),
(37, 73, '20', '0', 'venue', 'venue_2016-01-04932.jpg', '2016-01-03 23:49:35', '2016-01-03 23:49:35'),
(38, 73, '20', '0', 'venue', 'venue_2016-01-0413581.jpg', '2016-01-03 23:49:35', '2016-01-03 23:49:35'),
(39, 73, '20', '0', 'venue', 'venue_2016-01-0415554.jpg', '2016-01-03 23:49:35', '2016-01-03 23:49:35'),
(40, 73, '20', '0', 'venue', 'venue_2016-01-0410963.jpg', '2016-01-03 23:49:36', '2016-01-03 23:49:36'),
(41, 73, '20', '0', 'venue', 'venue_2016-01-0413840.jpg', '2016-01-03 23:49:36', '2016-01-03 23:49:36');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2014_10_12_000000_create_users_table', 1),
('2014_10_12_100000_create_password_resets_table', 1),
('2015_11_26_111147_create_venues_table', 1),
('2015_11_26_112043_create_staff_table', 1),
('2015_11_26_112341_create_event_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`),
  KEY `password_resets_token_index` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rewards`
--

CREATE TABLE IF NOT EXISTS `rewards` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `call_count` int(11) DEFAULT NULL,
  `call_type` varchar(255) DEFAULT '',
  `reward_points` varchar(255) DEFAULT '',
  `event_id` int(11) DEFAULT '0',
  `venue_id` int(11) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=604 ;

--
-- Dumping data for table `rewards`
--

INSERT INTO `rewards` (`id`, `user_id`, `call_count`, `call_type`, `reward_points`, `event_id`, `venue_id`, `created_at`, `updated_at`) VALUES
(510, 73, 1, 'login', '5', 0, 0, '2015-12-23 04:03:26', '0000-00-00 00:00:00'),
(511, 77, 1, 'login', '5', 0, 0, '2015-12-23 04:04:10', '0000-00-00 00:00:00'),
(512, 77, 1, 'event', '5', 0, 0, '2015-12-23 04:04:16', '0000-00-00 00:00:00'),
(513, 73, 1, 'event', '5', 0, 0, '2015-12-23 04:52:35', '0000-00-00 00:00:00'),
(514, 77, 1, 'ripple', '20', 0, 14, '2015-12-23 05:02:08', '0000-00-00 00:00:00'),
(515, 87, 1, 'login', '5', 0, 0, '2015-12-23 07:14:02', '0000-00-00 00:00:00'),
(516, 75, 1, 'invite', '20', 0, 0, '2015-12-23 07:15:47', '0000-00-00 00:00:00'),
(517, 75, 1, 'invite', '20', 0, 0, '2015-12-23 07:17:16', '0000-00-00 00:00:00'),
(518, 75, 1, 'invite', '20', 0, 0, '2015-12-23 07:17:57', '0000-00-00 00:00:00'),
(519, 75, 1, 'invite', '20', 0, 0, '2015-12-23 07:17:59', '0000-00-00 00:00:00'),
(520, 75, 1, 'invite', '20', 0, 0, '2015-12-23 07:18:02', '0000-00-00 00:00:00'),
(521, 73, 1, 'invite', '20', 0, 0, '2015-12-23 07:52:11', '0000-00-00 00:00:00'),
(522, 77, 1, 'invite', '20', 0, 0, '2015-12-23 07:54:28', '0000-00-00 00:00:00'),
(523, 77, 1, 'invite', '20', 0, 0, '2015-12-23 07:54:44', '0000-00-00 00:00:00'),
(524, 77, 1, 'invite', '20', 0, 0, '2015-12-23 07:55:19', '0000-00-00 00:00:00'),
(525, 77, 1, 'invite', '20', 0, 0, '2015-12-23 07:56:23', '0000-00-00 00:00:00'),
(526, 89, 1, 'login', '5', 0, 0, '2015-12-23 08:04:49', '0000-00-00 00:00:00'),
(527, 77, 1, 'invite', '20', 0, 0, '2015-12-23 08:07:19', '0000-00-00 00:00:00'),
(528, 76, 1, 'login', '5', 0, 0, '2015-12-23 08:53:58', '0000-00-00 00:00:00'),
(529, 89, 1, 'event', '5', 0, 0, '2015-12-23 09:31:17', '0000-00-00 00:00:00'),
(530, 90, 1, 'event', '5', 0, 0, '2015-12-23 09:32:37', '0000-00-00 00:00:00'),
(531, 91, 1, 'event', '5', 0, 0, '2015-12-23 09:51:46', '0000-00-00 00:00:00'),
(532, 91, 1, 'ripple', '20', 24, 0, '2015-12-23 09:52:45', '0000-00-00 00:00:00'),
(533, 91, 1, 'event', '5', 0, 0, '2015-12-24 09:55:39', '0000-00-00 00:00:00'),
(534, 77, 1, 'login', '5', 0, 0, '2015-12-28 04:29:00', '0000-00-00 00:00:00'),
(535, 77, 1, 'event', '5', 0, 0, '2015-12-28 04:31:01', '0000-00-00 00:00:00'),
(536, 76, 1, 'login', '5', 0, 0, '2015-12-28 04:58:46', '0000-00-00 00:00:00'),
(537, 76, 1, 'invite', '20', 0, 0, '2015-12-28 05:07:46', '0000-00-00 00:00:00'),
(538, 75, 1, 'login', '5', 0, 0, '2015-12-28 06:24:09', '0000-00-00 00:00:00'),
(539, 75, 1, 'event', '5', 0, 0, '2015-12-28 06:31:39', '0000-00-00 00:00:00'),
(540, 75, 1, 'ripple', '20', 17, 0, '2015-12-28 06:42:56', '0000-00-00 00:00:00'),
(541, 78, 1, 'event', '5', 0, 0, '2015-12-28 06:44:29', '0000-00-00 00:00:00'),
(542, 92, 1, 'login', '5', 0, 0, '2015-12-28 06:55:06', '0000-00-00 00:00:00'),
(543, 92, 1, 'event', '5', 0, 0, '2015-12-28 06:55:15', '0000-00-00 00:00:00'),
(544, 92, 1, 'ripple', '20', 0, 11, '2015-12-28 06:55:40', '0000-00-00 00:00:00'),
(545, 92, 1, 'ripple', '20', 0, 10, '2015-12-28 06:55:54', '0000-00-00 00:00:00'),
(546, 92, 1, 'ripple', '20', 0, 12, '2015-12-28 06:56:05', '0000-00-00 00:00:00'),
(547, 92, 1, 'ripple', '20', 0, 16, '2015-12-28 06:56:15', '0000-00-00 00:00:00'),
(548, 92, 1, 'invite', '20', 0, 0, '2015-12-28 06:56:41', '0000-00-00 00:00:00'),
(549, 92, 1, 'ripple', '20', 0, 13, '2015-12-28 06:57:34', '0000-00-00 00:00:00'),
(550, 92, 1, 'ripple', '20', 0, 14, '2015-12-28 06:57:42', '0000-00-00 00:00:00'),
(551, 80, 1, 'login', '5', 0, 0, '2015-12-28 07:33:57', '0000-00-00 00:00:00'),
(552, 73, 1, 'login', '5', 0, 0, '2015-12-29 00:22:01', '0000-00-00 00:00:00'),
(553, 73, 1, 'event', '5', 0, 0, '2015-12-29 00:22:09', '0000-00-00 00:00:00'),
(554, 77, 1, 'login', '5', 0, 0, '2015-12-29 08:43:21', '0000-00-00 00:00:00'),
(555, 76, 1, 'login', '5', 0, 0, '2015-12-29 08:43:45', '0000-00-00 00:00:00'),
(556, 73, 1, 'login', '5', 0, 0, '2015-12-30 00:29:48', '0000-00-00 00:00:00'),
(557, 73, 1, 'event', '5', 0, 0, '2015-12-30 00:46:18', '0000-00-00 00:00:00'),
(558, 77, 1, 'event', '5', 0, 0, '2015-12-30 03:41:43', '0000-00-00 00:00:00'),
(559, 77, 1, 'ripple', '20', 0, 17, '2015-12-30 06:27:03', '0000-00-00 00:00:00'),
(560, 77, 1, 'ripple', '20', 0, 16, '2015-12-30 06:28:34', '0000-00-00 00:00:00'),
(561, 77, 1, 'ripple', '20', 0, 14, '2015-12-30 06:28:41', '0000-00-00 00:00:00'),
(562, 77, 1, 'ripple', '20', 0, 13, '2015-12-30 06:28:50', '0000-00-00 00:00:00'),
(563, 77, 1, 'ripple', '20', 18, 0, '2015-12-30 06:29:07', '0000-00-00 00:00:00'),
(564, 75, 1, 'ripple', '20', 0, 10, '2015-12-30 06:34:43', '0000-00-00 00:00:00'),
(565, 77, 1, 'login', '5', 0, 0, '2015-12-30 08:55:48', '0000-00-00 00:00:00'),
(566, 75, 1, 'event', '5', 0, 0, '2015-12-30 09:06:20', '0000-00-00 00:00:00'),
(567, 75, 1, 'like', '20', 0, 0, '2015-12-30 09:29:17', '0000-00-00 00:00:00'),
(568, 77, 1, 'like', '20', 0, 10, '2015-12-30 09:30:46', '0000-00-00 00:00:00'),
(569, 76, 1, 'login', '5', 0, 0, '2015-12-30 10:10:20', '0000-00-00 00:00:00'),
(570, 93, 1, 'login', '5', 0, 0, '2015-12-30 10:12:13', '0000-00-00 00:00:00'),
(571, 75, 1, 'like', '20', 0, 10, '2015-12-30 10:42:00', '0000-00-00 00:00:00'),
(572, 75, 1, 'like', '20', 10, 0, '2015-12-30 10:45:29', '0000-00-00 00:00:00'),
(573, 76, 1, 'like', '20', 0, 18, '2015-12-30 11:07:56', '0000-00-00 00:00:00'),
(574, 76, 1, 'event', '5', 0, 0, '2015-12-30 11:08:43', '0000-00-00 00:00:00'),
(575, 76, 1, 'like', '20', 30, 0, '2015-12-30 11:09:38', '0000-00-00 00:00:00'),
(576, 77, 1, 'like', '20', 16, 0, '2015-12-30 11:34:07', '0000-00-00 00:00:00'),
(577, 73, 1, 'login', '5', 0, 0, '2015-12-31 00:59:13', '0000-00-00 00:00:00'),
(578, 73, 1, 'event', '5', 0, 0, '2015-12-31 00:59:18', '0000-00-00 00:00:00'),
(579, 77, 1, 'event', '5', 0, 0, '2015-12-31 06:14:14', '0000-00-00 00:00:00'),
(580, 77, 1, 'like', '20', 30, 0, '2015-12-31 07:57:02', '0000-00-00 00:00:00'),
(581, 77, 1, 'like', '20', 0, 18, '2015-12-31 09:07:12', '0000-00-00 00:00:00'),
(582, 75, 1, 'like', '20', 4, 0, '2015-12-31 09:24:07', '0000-00-00 00:00:00'),
(583, 77, 1, 'login', '5', 0, 0, '2015-12-31 09:24:13', '0000-00-00 00:00:00'),
(584, 75, 1, 'ripple', '20', 30, 0, '2015-12-31 09:33:24', '0000-00-00 00:00:00'),
(585, 75, 1, 'ripple', '20', 0, 18, '2015-12-31 09:35:40', '0000-00-00 00:00:00'),
(586, 76, 1, 'like', '20', 0, 19, '2015-12-31 09:55:29', '0000-00-00 00:00:00'),
(587, 76, 1, 'ripple', '20', 0, 20, '2015-12-31 10:05:36', '0000-00-00 00:00:00'),
(588, 76, 1, 'login', '5', 0, 0, '2015-12-31 10:23:57', '0000-00-00 00:00:00'),
(589, 76, 1, 'event', '5', 0, 0, '2015-12-31 11:18:27', '0000-00-00 00:00:00'),
(590, 89, 1, 'login', '5', 0, 0, '2015-12-31 12:03:26', '0000-00-00 00:00:00'),
(591, 91, 1, 'event', '5', 0, 0, '2015-12-31 13:37:42', '0000-00-00 00:00:00'),
(592, 73, 1, 'login', '5', 0, 0, '2016-01-01 01:00:20', '0000-00-00 00:00:00'),
(593, 73, 1, 'event', '5', 0, 0, '2016-01-01 01:15:28', '0000-00-00 00:00:00'),
(594, 94, 1, 'login', '5', 0, 0, '2016-01-01 03:06:21', '0000-00-00 00:00:00'),
(595, 75, 1, 'login', '5', 0, 0, '2016-01-01 05:05:40', '0000-00-00 00:00:00'),
(596, 75, 1, 'like', '20', 0, 22, '2016-01-01 06:12:39', '0000-00-00 00:00:00'),
(597, 75, 1, 'event', '5', 0, 0, '2016-01-01 06:18:48', '0000-00-00 00:00:00'),
(598, 95, 1, 'event', '5', 0, 0, '2016-01-01 07:11:50', '0000-00-00 00:00:00'),
(599, 96, 1, 'login', '5', 0, 0, '2016-01-01 07:15:16', '0000-00-00 00:00:00'),
(600, 96, 1, 'event', '5', 0, 0, '2016-01-01 07:15:42', '0000-00-00 00:00:00'),
(601, 96, 1, 'like', '20', 0, 22, '2016-01-01 07:17:25', '0000-00-00 00:00:00'),
(602, 97, 1, 'login', '5', 0, 0, '2016-01-01 07:40:38', '0000-00-00 00:00:00'),
(603, 97, 1, 'like', '20', 35, 0, '2016-01-01 07:41:07', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `staff_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `staff_login_id` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `staff_phone` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `first_name` varchar(30) COLLATE utf8_unicode_ci DEFAULT '',
  `last_name` varchar(30) COLLATE utf8_unicode_ci DEFAULT '',
  `phone_number` varchar(15) COLLATE utf8_unicode_ci DEFAULT '',
  `email_address` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `created_by` int(10) NOT NULL DEFAULT '0',
  `facebook_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT '0',
  `radius` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `user_type` enum('user','venue_owner','staff','admin') COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=98 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `staff_name`, `staff_login_id`, `staff_phone`, `first_name`, `last_name`, `phone_number`, `email_address`, `password`, `created_by`, `facebook_id`, `radius`, `user_type`, `remember_token`, `created_at`, `updated_at`) VALUES
(72, '', '', '', 'Umar Shahzad', '', '', '', '$2y$10$PVShxwHSKQ.9mQ6Rv.KoPOdRGyMLlPi94oDxsQp9MT1pglL6i6Lu6', 0, '555744411259707', '', 'venue_owner', NULL, '2015-12-22 02:47:39', '2015-12-22 02:47:39'),
(73, '', '', '', 'gdfgdfg', 'fgdfgfd', '789456', 'a@b.com', '$2y$10$5aXzNUKZy9PjWjXN1iYxhuxKWcATYwyAVr6Uij6d0qP2ew9hdfHnG', 0, '0', '', 'user', 'Mz4adqFvPSqq8B9H2DF8taQFvgltWuX9kWeDgBdbmzuZJ9f8YaAPvDSot68s', '2015-12-22 02:48:39', '2015-12-22 02:48:55'),
(74, '', '', '', 'Ahana Khan', '', '', '', '$2y$10$j7xEh0uXHV2AssC9.DPDRuyTbaVWclSPNDxeFC0UKTtnuU2.Wtwiu', 0, '1648438585407551', '', 'venue_owner', NULL, '2015-12-22 02:55:34', '2015-12-22 02:55:34'),
(75, '', '', '', 'jhon', 'owh', '+1236478236', 'jahonowh09@gmail.com', '$2y$10$ssBAXbepOkuhKONn5BSEnetfQqp5VBVPBxRny5IWkuMN3affWv26u', 0, '0', '', 'venue_owner', 'AKeLTujeOsguiwCb3KmcV7zEX9d4LtSDqD9tahfBa3sZ06M3hcdZS7Ow9n8I', '2015-12-22 03:41:59', '2015-12-22 03:43:06'),
(76, '', '', '', 'Riz', 'K', '147853962', 'bc100403317@gmail.com', '$2y$10$kfRthGZtUSKgRcLrHmkzdOWFQpFHERqep14NYQvQnm4HXHBRnuVXm', 0, '0', '200', 'venue_owner', '5Sm868GdRNWkby1wvEqCLCUZEkaq6LDBPDim4gzDNW3DR3CN18gOp5B6E7bA', '2015-12-22 05:02:51', '2015-12-22 05:03:21'),
(77, '', '', '', 'R', 'K', '147852369', 'm.rizwan@curiologix.com', '$2y$10$0/aOvlrl9Yr12umshkG9quQ0YCT6lviWDV3.GK6aowFsWgT5Hdih.', 0, '0', '', 'user', 'n6oZjyKT36hPQuqJiFekxiRmleTLRO2pJfbg0hQRXMUw3IFQssnsNPmdJAwD', '2015-12-22 05:06:07', '2015-12-22 05:06:28'),
(78, 'markpual', '', '+13692587456', '', '', '', 'markpual890@gmail.com', '$2y$10$cuQNT7vIyGIWjwK68Z7y5OmrUF0Jh.13GTT9yBJ3zoU9y0Rs.zVza', 75, '0', '', 'staff', NULL, '2015-12-22 06:23:50', '2015-12-22 06:23:50'),
(79, 'steven', '', '+13642563222', '', '', '', 'davednill09@gmail.com', '$2y$10$MwcEcMbIvwaqfWzAeqpyzOp6uyKz/iRQgl5FHfvzFwgkAgW0S67KG', 0, '0', '', 'staff', NULL, '2015-12-22 06:26:01', '2015-12-22 06:26:01'),
(80, 'jaff', '', '963852147', '', '', '', 'jaffmaya@gmail.com', '$2y$10$difnDuT41bAsUQwPtB6Dve4kuvk/Gbq29ESbvKVdjdG.qy3fkFk8G', 75, '0', '', 'staff', 'BY0GIKpeY3TLbBdZ33ly22d3KWtbKPi8c1ryrnB7jwIXh53LZ1qUBhSgSrZn', '2015-12-22 06:57:30', '2015-12-22 08:09:09'),
(81, '', '', '', 'marie', 'gill', '08523994119795', 'jaffmaya@hotmail.com', '$2y$10$KQs8e51q1jkpjGf2cdym6O0I8Ox0rPPoMWC/BmX3b0Dv1E95Q3rkO', 0, '0', '', 'venue_owner', 'f98pIS2oet5pUCZwWGlrhOmkbdiLg4VnpVNF8PcPccH337huUaDfmO2xl2ZF', '2015-12-22 07:00:24', '2015-12-22 07:22:58'),
(82, 'charles', '', '0852369147', '', '', '', 'bushra.khan@curiologix.com', '$2y$10$0efdIXaxCOgAo1T4xYLYLeB10r.Fb9PFa3s8axW4K/BoeKIlbxaeC', 81, '0', '', 'staff', NULL, '2015-12-22 07:33:01', '2015-12-22 07:33:01'),
(83, '', '', '', 'josph', 'kevin', '0852369741', 'josphkevin@hotmail.com', '$2y$10$smclv8Dvt5/Cjqy/McijqOqCdYLlX6K7RCZbi8fjBQPtKDCUzL7sC', 0, '0', '', 'user', NULL, '2015-12-22 07:36:03', '2015-12-22 07:36:03'),
(84, '', '', '', 'mark', 'paul', '082399744', 'markpaul@yahoo.com', '$2y$10$CZxnybpDhTsTJqEthK.rB.b8d7d4Q85ypQkFoyQqaviOOyJYiayS2', 0, '0', '500', 'venue_owner', 'tkFAHlFsFs7vHYSocPo2dSjXqpesuYqVc6vE5nhn7dnGt7Iwv3x2PKhEjYIv', '2015-12-22 07:37:37', '2015-12-22 07:55:00'),
(85, '', '', '', 'ronald', 'jaff', '0826935178', 'ronald@yahoo.com', '$2y$10$CKQ/7uQHV5HMsv6ln7L7n.Ai4Euzzd8u/gd87y/VRUWi80tY9j5xK', 0, '0', '', 'user', 'ALZFIWsMRaBUTz6EPUUpfN4jVPxbstbq1PWtkrRrX0e7bPhms1v2WkU2MtQo', '2015-12-22 07:39:03', '2015-12-22 07:39:26'),
(86, '', '', '', 'marie', 'ali', '082697349496494', 'marie@hotmail.com', '$2y$10$P8qW073/kplv4SJi6Y4RLeGzXHyy6i93tvCtKl9WMlqyYKUoHAhay', 0, '0', '', 'user', 'kYYIDZCFHj2KLtdiqTjCDpG2MTPHmWS7YF7FgP43TD6RQvGVWvfPGlWpINds', '2015-12-22 08:28:53', '2015-12-22 08:29:24'),
(87, '', '', '', 'Abdul', 'Mannan', '03214991257', 'mannan@curiologix.com', '$2y$10$BddIFxkQyuIGPO3XOrtxfuOzFXZp0SaOMS7u43MwJ1VwljNX1SxOK', 0, '0', '', 'user', 'rTZDZmLdrSJeCXzeTuO2Nxfb4dOsatQuZkHrd5MqRz7udXB8jFrhp2PLeFrl', '2015-12-22 13:05:13', '2015-12-22 13:05:22'),
(88, '', '', '', 'shahzad', 'hussain', '79854222', 'shahzadshahg@hotmail.com', '$2y$10$ek6SeCzS3P/fi1WT1Z7vM.4dLq.XY/3Yy46Sq3Cpt36S9CMmWOpNK', 0, '0', '', 'user', 'Lflh0pvfLxt6rhCKpxhzDMvQOT470jzejVAVBiUDC0CsqRv5nlrXTZGGrEWN', '2015-12-23 03:54:07', '2015-12-23 03:54:34'),
(89, '', '', '', 'Abdul', 'Mannan', '03214991257', 'mannan1@curiologix.com', '$2y$10$K539sZl.4W9YTudi3nB86eadvilZlaEhYwfZV65QEGCq9VTlifIa.', 0, '0', '', 'venue_owner', 'DIFHUDFwconajVeFfhoMSCAGxs54mpq5w83hmXa4Dsfr45BalfwFBT1vzbMF', '2015-12-23 08:04:13', '2015-12-23 08:04:49'),
(90, 'Jack Lawrence ', '', '1222334554', '', '', '', 'jack@marquette.com', '$2y$10$6LXiN0wAJgWGy1QV44vub.4Ue0mLXcvpUGYKsVUXW42I1V8go3GO2', 89, '0', '', 'staff', NULL, '2015-12-23 09:31:47', '2015-12-23 09:31:47'),
(91, '', '', '', 'Cire Sonej', '', '', '', '$2y$10$12djrQ9ol3QMigEFUzi6zOJBbfJXKTVKDPUngxmPwSuOBrWTay6Si', 0, '10100810060395004', '', 'user', NULL, '2015-12-23 09:50:54', '2015-12-23 09:50:54'),
(92, '', '', '', 'Haris', 'Rana', '03662553690', 'haris@hotmail.com', '$2y$10$JAcVHuS6uaRR.dHnYWAKfevQgws.yr4uXLX3vgf11dggXp4/E8wLm', 0, '0', '', 'user', 'ceSBZuSWv2bgo2W6kTnQw5b2CtBAjbsy1teOu3CwXUs1CfRVV3rJOCTvTFW3', '2015-12-28 06:54:10', '2015-12-28 06:55:06'),
(93, 'John William', '', '147852369', '', '', '', 'brownsunny45@gmail.com', '$2y$10$3aYYHghvBXqoGsZeCbGSEeVO8Mb5em2uxOfIBq8Qi1jl7LV9GjGNu', 76, '0', '', 'staff', 'yTBcqvA1RWgJe7J4iymqm5sLH4R109NpYgjMrPVXY1BIgHqQtqfmJOGsFHar', '2015-12-30 10:10:53', '2015-12-30 10:12:13'),
(94, '', '', '', 'dfndfj', 'vdfvf', '456789', 'm@r.com', '$2y$10$4Leu0HlqqUQAzXGi42R56O5OhpCfWT96As2udNGsr8Da8UDj9ShQ2', 0, '0', '', 'venue_owner', 'RqSMRMrRAkNKE5CGTi9lq6y2EZqPiv0AkMeJdQDBUBIG87zSuYqDUsxhuhbB', '2016-01-01 03:06:04', '2016-01-01 03:06:21'),
(95, 'Steven', '', '741258369', '', '', '', 'stevengill930@gmail.com', '$2y$10$xtOUgsR9VLReeQxohmrpYONewIRdRclggIfuZa5fOrNRbJSK.EVG6', 75, '0', '', 'staff', NULL, '2016-01-01 07:02:03', '2016-01-01 07:02:03'),
(96, '', '', '', 'Marwa', 'Deward', '8523697412', 'marwa@gmail.com', '$2y$10$B4wSXIPaO0Izri7JLHa6meflpUUHZlL7b2g1hfn/X3L4kIf5BvJsi', 0, '0', '', 'user', '1507MQJp0ka82teZdFhkqIO2Papn86ylP09uE8tVmPXX8cp0Ycx5DyLuVfVg', '2016-01-01 07:14:49', '2016-01-01 07:15:16'),
(97, 'Steven', '', '852369742', '', '', '', 'stevengill903@gmail.com', '$2y$10$aZAOWHHWqHwujLnCJyVbHOF80O1UmFhKm1nHRn/bK.3geh51p.b8W', 75, '0', '', 'staff', '4hBW6Bvs6EOIlYZI3MfdavWZAIEX2VZMdHH8db1a9T8G2nBSpn2JZaPBDNza', '2016-01-01 07:36:01', '2016-01-01 07:40:38');

-- --------------------------------------------------------

--
-- Table structure for table `venues`
--

CREATE TABLE IF NOT EXISTS `venues` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `venue_name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `venue_address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `city` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `state` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `postal_code` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `venue_phone` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `venue_website` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `venue_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `time_from` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `time_to` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `latitude` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `longitude` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `days_closed` enum('Saturday','Sunday') COLLATE utf8_unicode_ci NOT NULL,
  `photo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=23 ;

--
-- Dumping data for table `venues`
--

INSERT INTO `venues` (`id`, `user_id`, `venue_name`, `venue_address`, `description`, `city`, `state`, `postal_code`, `venue_phone`, `venue_website`, `venue_email`, `time_from`, `time_to`, `latitude`, `longitude`, `days_closed`, `photo`, `created_at`, `updated_at`, `deleted_at`) VALUES
(19, 76, 'Bolaan', 'Lane 2', 'This venue is only for social events.', 'Lahore', 'Punjab', '57000', '258741369', 'www.bolaan.com', 'bolaan@gmail.com', '07 : 53  PM', '11 : 53  PM', '31.550784390603557', '74.35326498001814', 'Sunday', 'venue_2015-12-311893716613.png,venue_2015-12-312141600914.png', '2015-12-31 09:54:05', '2015-12-31 09:54:05', NULL),
(20, 76, 'Burraq Marriage Hall', '132 Allama Iqbal Rd', 'This hall is specified for weddings.', 'Lahore', 'Punjab', '57000', '147852369', 'www.burraq.com', 'buraaq@gmail.com', '08 : 04  PM', '11 : 04  PM', '31.554611743640006', '74.35715418308973', 'Sunday', 'venue_2015-12-311775483783.png,venue_2015-12-312118337155.png', '2015-12-31 10:05:18', '2015-12-31 10:05:18', NULL),
(21, 0, 'Wedding planner', 'Strada Observatorului 20', 'Here is the place where your dreams come ture', 'Brădet', 'Covasna County', '00000', '85239971196767', 'www.google.com', 'wedding@gmail.com', '03 : 49  PM', '04 : 49  PM', '45.66239134279629', '26.00868310779333', '', 'venue_2016-01-01707580417.png,venue_2016-01-011025989138.png', '2016-01-01 05:53:38', '2016-01-01 05:53:38', NULL),
(22, 75, 'Wedding palace', 'Innamincka SA 5731', 'Here is the where your dream becomes true', 'Innamincka', 'South Australia', '0000', '85236974566', 'www.google.com', 'wedding@hotmail.com', '04 : 10  PM', '06 : 10  PM', '-27.050414491815474', '140.1894612237811', 'Saturday', 'venue_2016-01-011120335910.png,venue_2016-01-012056153952.png', '2016-01-01 06:11:57', '2016-01-01 06:11:57', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `venue_ratings`
--

CREATE TABLE IF NOT EXISTS `venue_ratings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `venue_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `likes` int(11) NOT NULL,
  `venue_likes` int(11) NOT NULL,
  `favourites` int(11) NOT NULL,
  `type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `event_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=50 ;

--
-- Dumping data for table `venue_ratings`
--

INSERT INTO `venue_ratings` (`id`, `user_id`, `venue_id`, `likes`, `venue_likes`, `favourites`, `type`, `event_id`, `created_at`, `updated_at`) VALUES
(45, 76, '19', 0, 0, 1, 'venue', '0', '2015-12-31 09:55:29', '2015-12-31 09:55:29'),
(46, 76, '20', 1, 0, 0, 'venue', '0', '2015-12-31 10:05:36', '2015-12-31 10:05:36'),
(47, 75, '22', 0, 1, 1, 'venue', '0', '2016-01-01 06:12:30', '2016-01-01 06:12:30'),
(48, 96, '22', 0, 1, 1, 'venue', '0', '2016-01-01 07:17:19', '2016-01-01 07:17:19'),
(49, 97, '22', 0, 0, 0, 'venue', '0', '2016-01-01 07:41:27', '2016-01-01 07:41:27');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
