<table border="0" cellpadding="0" cellspacing="0" height="100%" width="100%">
    <tbody>
    <tr>
        <td align="center" valign="top">
            <table border="0" cellpadding="0" cellspacing="0" width="600" id="ecxtemplate_container" style="box-shadow:0 1px 4px rgba(0,0,0,0.1)  !important;background-color:#fdfdfd;border-radius:3px !important;">
                <tbody>
                <tr>
                    <td align="center" valign="top">

                        <table border="0" cellpadding="0" cellspacing="0" width="600" id="ecxtemplate_header" style="background-color:#557da1;border-radius:3px 3px 0 0 !important;color:#ffffff;border-bottom:0;width: 100%;text-align: center;font-weight: bolder;font-family: Arial, Sans-serif;">
                            <tbody>
                            <tr>
                                <td>
                                    <h1 style="color:#ffffff;display:block; font-size:30px;font-weight:600;line-height:150%;padding:36px 48px 5px 48px; text-align:left;text-shadow:0 1px 0 #7797b4">Rypls</h1>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td align="center" valign="top">
                        <table border="0" cellpadding="0" cellspacing="0" width="600" id="ecxtemplate_body">
                            <tbody>
                            <tr>
                                <td valign="top" id="ecxbody_content" style="background-color:#fdfdfd; padding:48px;">
                                    {!! $content !!}
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td align="center" valign="top">
                        <table border="0" cellpadding="10" cellspacing="0" width="600" id="ecxtemplate_footer" style="border-top:0;">
                            <tbody>
                            <tr>
                                <td valign="top" style="padding:0;">
                                    <table border="0" cellpadding="10" cellspacing="0" width="100%">
                                        <tbody>
                                        <tr>
                                            <td colspan="2" valign="middle" id="ecxcredit" style="border:0;color:#99b1c7;font-family:Arial;font-size:22px;line-height:125%;text-align:center;padding:0 48px 48px 48px;"><p> Come Experience Our Superior Customer Service!</p></td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </td>
                </tr>
                </tbody>
            </table>
        </td>
    </tr>
    </tbody>
</table>
