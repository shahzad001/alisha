<?php


class UploaderService
{

}