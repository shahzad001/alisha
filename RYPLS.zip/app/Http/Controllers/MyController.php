<?php

namespace App\Http\Controllers;

use App\Event;
use App\User;
use App\Venue;
use App\VenueRating;

use App\Http\Requests;
use Illuminate\Support\Facades\DB;
use Witty\LaravelPushNotification\PushNotification;


class MyController extends Controller
{

    protected $venue = null;
    public function __construct(Venue $venue)
    {
        $this->venue = $venue;
    }

    /**
     * This function has data fetched from VENUES table only
     *
     * @param $venues
     * @param $user_id
     * @return array
     */
    protected function getVenuesLikes($venues, $user_id){

        $tempArray = [];
        $date = date('Y-m-d');
        foreach ($venues as $index => $venue) {
            $columns = ['likes AS ripple','favourites','venue_likes AS like'];
            $venue_likes = DB::table('venue_ratings')->where('user_id', $user_id)->where('venue_id', $venue->id)->select($columns)->first();
            $likes = DB::table('venue_ratings')->where('user_id', $user_id)->where('venue_id', $venue->id)->where('created_at', 'like', '%'.$date.'%')->select($columns)->first();
            $eventCount = DB::table('event')->where('venue_id', $venue->id)->count();
            $rippleCount = DB::table('venue_ratings')->where('venue_id', $venue->id)->where('likes',1)->where('created_at', 'like', '%'.$date.'%')->count();
            $likeCount = DB::table('venue_ratings')->where('venue_id', $venue->id)->where('venue_likes',1)->count();
            if($likes) {
                $venue->like = $venue_likes->like;
                $venue->ripple = $likes->ripple;
                $venue->favourites = $likes->favourites;
                $venue->eventCount = 0;
                $venue->rippleCount = 0;
                $venue->likeCount = 0;
            } else {
                $venue->like = 0;
                $venue->ripple = 0;
                $venue->favourites = 0;
                $venue->eventCount = 0;
                $venue->rippleCount = 0;
                $venue->likeCount = 0;
            }

            if($eventCount) {
                $venue->eventCount = $eventCount;
            }
            if($rippleCount){
                $venue->rippleCount = $rippleCount;
            }
            if($likeCount){
                $venue->likeCount = $likeCount;
            }

            $tempArray[$index] = $venue;
        }
        return $tempArray;
    }

    /**
     * This function has data fetched from VENUE & VENUE Rating table
     *
     * @param $venues
     * @param $user_id
     * @return array
     */


    protected function getJointVenuesLikes($venues, $user_id){

        $tempArray = [];
        $date = date('Y-m-d');
        foreach ($venues as $index => $venue) {
            $columns = ['likes AS ripple','favourites','venue_likes AS like'];
            $venue_likes = DB::table('venue_ratings')->where('user_id', $user_id)->where('venue_id', $venue->venue_id)->select($columns)->first();
            $likes = DB::table('venue_ratings')->where('user_id', $user_id)->where('venue_id', $venue->venue_id)->where('created_at', 'like', '%'.$date.'%')->select($columns)->first();
            $eventCount = DB::table('event')->where('venue_id', $venue->venue_id)->count();
            $rippleCount = DB::table('venue_ratings')->where('venue_id', $venue->venue_id)->where('likes',1)->where('created_at', 'like', '%'.$date.'%')->count();
            $likeCount = DB::table('venue_ratings')->where('venue_id', $venue->venue_id)->where('venue_likes',1)->count();
            if($likes) {
                $venue->like = $venue_likes->like;
                $venue->ripple = $likes->ripple;
                $venue->favourites = $likes->favourites;
                $venue->eventCount = 0;
                $venue->rippleCount = 0;
                $venue->likeCount = 0;

            } else {
                $venue->like = 0;
                $venue->ripple = 0;
                $venue->favourites = 0;
                $venue->eventCount = 0;
                $venue->rippleCount = 0;
                $venue->likeCount = 0;
            }

            if($eventCount) {
                $venue->eventCount = $eventCount;
            }
            if($rippleCount){
                $venue->rippleCount = $rippleCount;
            }
            if($likeCount){
                $venue->likeCount = $likeCount;
            }

            $tempArray[$index] = $venue;
        }
        return $tempArray;
    }

    /**
     * this functtion is used by data fetche from EVENTS table only
     *
     * @param $events
     * @param null $user_id
     * @return array
     */
    protected function  getEventsLikes($events, $user_id = null)
    {
        $tempArray = [];
        $date = date('Y-m-d');
        foreach ($events as $index => $event) {
            $columns = ['likes AS ripple', 'favourites','event_likes AS like'];
            if(isset($event->event_id))
                $event_id = $event->event_id;
            else
                $event_id = $event->id;
            if(!empty($user_id)) {
                $event_likes = DB::table('event_ratings')->where('user_id', $user_id)->where('event_id', $event->id)->select($columns)->first();
                $likes = DB::table('event_ratings')->where('user_id', $user_id)->where('event_id', $event_id)->where('created_at', 'like', '%'.$date.'%')->select($columns)->first();

            } else {
                $event_likes = DB::table('event_ratings')->where('event_id', $event->id)->where('created_at', 'like', '%'.$date.'%')->select($columns)->first();
                $likes = DB::table('event_ratings')->where('event_id', $event_id)->where('created_at', 'like', '%'.$date.'%')->select($columns)->first();
            }
            $rippleCount = DB::table('event_ratings')->where('event_id', $event_id)->where('likes', 1)->where('created_at', 'like', '%'.$date.'%')->count();
            $likeCount = DB::table('event_ratings')->where('event_id', $event->id)->where('event_likes',1)->count();
            if ($likes) {
                $event->like = $event_likes->like;
                $event->ripple = $likes->ripple;
                $event->favourites = $likes->favourites;
                $event->rippleCount = 0;
                $event->likeCount = 0;

            } else {
                $event->like = 0;
                $event->ripple = 0;
                $event->favourites = 0;
                $event->rippleCount = 0;
                $event->likeCount = 0;
            }
            if ($rippleCount) {
                $event->rippleCount = $rippleCount;
            }
            if($likeCount){
                $event->likeCount = $likeCount;
            }
            $tempArray[$index] = $event;
        }
        return $tempArray;
    }

    /**
     * this function is used data fetched by EVENTS & its RATING table JOIN
     *
     * @param $events
     * @param null $user_id
     * @return array
     */
    protected function getJoinedEventsLikes($events, $user_id = null)
    {
        $tempArray = [];
        $date = date('Y-m-d');
        foreach ($events as $index => $event) {
            $columns = ['likes AS ripple', 'favourites','event_likes AS like'];
            if(!empty($user_id)) {
                $event_likes = DB::table('event_ratings')->where('user_id', $user_id)->where('event_id', $event->event_id)->select($columns)->first();
                $likes = DB::table('event_ratings')->where('user_id', $user_id)->where('event_id', $event->event_id)->where('created_at', 'like', '%'.$date.'%')->select($columns)->first();
            } else {
                $event_likes = DB::table('event_ratings')->where('event_id', $event->event_id)->select($columns)->first();
                $likes = DB::table('event_ratings')->where('event_id', $event->event_id)->where('created_at', 'like', '%'.$date.'%')->select($columns)->first();
            }
            $rippleCount = DB::table('event_ratings')->where('event_id', $event->event_id)->where('likes', 1)->where('created_at', 'like', '%'.$date.'%')->count();
            $likeCount = DB::table('event_ratings')->where('event_id', $event->event_id)->where('event_likes',1)->count();
            if ($likes) {
                $event->like = $event_likes->like;
                $event->ripple = $likes->ripple;
                $event->favourites = $likes->favourites;
                $event->rippleCount = 0;
                $event->likeCount = 0;
            } else {
                $event->like = 0;
                $event->ripple = 0;
                $event->favourites = 0;
                $event->rippleCount = 0;
                $event->likeCount = 0;
            }
            if ($rippleCount) {
                $event->rippleCount = $rippleCount;
            }
            if($likeCount) {
                $event->likeCount = $likeCount;
            }
            $tempArray[$index] = $event;
        }
        return $tempArray;
    }

    function radiusQuery($user_lat, $user_long) {
        return 'IFNULL(
                (
                  (
                    (
                      ACOS(
                        SIN(
                          (
                            '.$user_lat.' * PI() / 180
                          )
                        ) * SIN((venues.`latitude` * PI() / 180)) + COS(
                          (
                            '.$user_lat.' * PI() / 180
                          )
                        ) * COS((venues.`latitude` * PI() / 180)) * COS(
                          (
                            (
                              '.$user_long.' - venues.`longitude`
                            ) * PI() / 180
                          )
                        )
                      )
                    ) * 180 / PI()
                  ) * 60 * 1.1515
                ),
                0
              ) AS `distance_miles` ';
    }

    public function sendPushNotification($device_id,$message, $deviceType)
    {
        PushNotification::app($deviceType)
            ->to($device_id)
            ->send($message);

    }
}
