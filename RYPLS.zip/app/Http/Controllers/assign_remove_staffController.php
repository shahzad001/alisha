<?php

namespace App\Http\Controllers;

use App\assign_remove_staff;
use App\Staff;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Validator;

class assign_remove_staffController extends Controller
{

    protected $assignStaff = null;
    public function __construct(assign_remove_staff $assignStaff)
    {
        $this->assignStaff = $assignStaff;
    }

    public function assignStaff(Request $request)
    {
        $id = $request->input('staff_name');
        $event_id = $request->input('event_name');
        $staff = [];
        $isAlready = DB::table('assign_remove_staff')->where('staff_name', '=', $id)->where('event_name', '=', $event_id)->count();
        if($isAlready > 0) {
            DB::table('assign_remove_staff')->where('staff_name', '=', $id)->where('event_name', '=', $event_id)->delete();
            $message = 'Staff has been removed Successfully!';
        } else {
            $staff = $this->assignStaff->assignStaff();
            $message = 'Duties has been assigned to staff Successfully!';
        }
        $resultArray = ['status' => 1, 'message' => $message, 'dataArray' => $staff];
        return Response::json($resultArray, 200);
    }
}
